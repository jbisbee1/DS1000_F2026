* ------------------------------------------------------------------------------
/* 	
*	Filename: 	extendedtable2.do
			
*	Purpose:	This do file produces the job satisfaction table in "Hybrid Working from Home 
Improves Retention Without Damaging Performance"

*	Created by: --
*	Created on: Aug 22, 2023
* 	Modified on: Aug 27, 2023
*/
* ------------------------------------------------------------------------------


clear
set more off
set scheme s2color

use "data/extendedtable2.dta", clear



* create a global with variables needed for the tabel
global VARS work_life_balance work_satisfaction life_satisfaction recommend_friends quit_intention

* compute the t-test for the treatment and control difference using the control indicator
est clear
estpost ttest $VARS, by(control)	

* output to latex table
esttab using "tables/extendedtable2.tex", replace ///
  cells("mu_2(fmt(3)) mu_1(fmt(3))  b() p(fmt(3)) count(fmt(0))") ///
  collabels("Control" "Treatment" "Diff." "p-value" "n" ) ///
  star(* 0.10 ** 0.05 *** 0.01) ///
  label booktabs nonum nogaps noobs compress	
	

 