# * ------------------------------------------------------------------------------
#   /* 	
#   *	Filename: 	null_test.R
# 
# *	Purpose:	This R script produces the null equivalence tests in "Hybrid Working from Home 
# Improves Retention Without Damaging Performance"
# 
# *	Created by: Mert Akan
# *	Created on: March 20, 2024
# * 	Modified on: March 20, 2024
# */
#   * ------------------------------------------------------------------------------

# install.packages("TOSTER")
library("TOSTER")

# Null Equivalence Test for *performance*
# 2021H2
tsum_TOST(m1=3.494,m2=3.449,sd1=0.831,sd2=0.842,n1=759,n2=748,eqb=0.5, alpha = 0.05, var.equal=FALSE,
          eqbound_type = "raw")
# 2022H1
tsum_TOST(m1=3.54,m2=3.51,sd1=0.821,sd2=0.816,n1=681,n2=674,eqb=0.5, alpha = 0.05, var.equal=FALSE,
          eqbound_type = "raw")
# 2022H2
tsum_TOST(m1=3.50,m2=3.52,sd1=0.845,sd2=0.829,n1=655,n2=646,eqb=0.5, alpha = 0.05, var.equal=FALSE,
          eqbound_type = "raw")
# 2023H1
tsum_TOST(m1=3.46,m2=3.41,sd1=0.887,sd2=0.923,n1=633,n2=621,eqb=0.5, alpha = 0.05, var.equal=FALSE,
          eqbound_type = "raw")



# Null Equivalence Test for *promotion*
# 2021H2
tsum_TOST(m1=6.919,m2=7.804,sd1=25.394,sd2=26.84,n1=766,n2=756,eqb=2.0, alpha = 0.05, var.equal=FALSE,
          eqbound_type = "raw")

# 2022H1
tsum_TOST(m1=2.597,m2=2.481,sd1=15.91,sd2=15.56,n1=693,n2=685,eqb=2.0, alpha = 0.05, var.equal=FALSE,
          eqbound_type = "raw")

# 2022H2
tsum_TOST(m1=4.08,m2=4.59,sd1=19.8,sd2=20.9,n1=661,n2=653,eqb=2.0, alpha = 0.05, var.equal=FALSE,
          eqbound_type = "raw")

# 2023H1
tsum_TOST(m1=2.93,m2=3.93,sd1=16.89,sd2=19.44,n1=647,n2=636,eqb=2.0, alpha = 0.05, var.equal=FALSE,
          eqbound_type = "raw")


# Null Equivalence Test for lines of code
tsum_TOST(m1=289.97,m2=280.36,sd1=1167,sd2=1010,n1=46767,n2=48727,eqb=29, alpha = 0.05, var.equal=FALSE,
          eqbound_type = "raw")



