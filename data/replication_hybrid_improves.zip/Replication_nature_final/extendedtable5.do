* ------------------------------------------------------------------------------
/* 	
*	Filename: 	extendedtable5.do
			
*	Purpose:	This do file produces performance and promotion heterogeneity in "Hybrid Working from Home 
Improves Retention Without Damaging Performance"

*	Created by: Mert Akan
*	Created on: Aug 27, 2023
* 	Modified on: March 20, 2024
*/
* ------------------------------------------------------------------------------


 
clear
set more off

* installing packages needed if not downloaded
cap which estout 
if _rc ssc install estout

* Performance regressions (N=1507)

eststo clear
use "data/extendedtable5/table5_left_a.dta",replace

eststo row_1: reghdfe performance treat, noabsorb 

eststo row_2_3: reghdfe performance children treat 1.children#1.treat, noabsorb 

use "data/extendedtable5/table5_left_b.dta",replace
eststo row_4_5: reghdfe performance live_far treat 1.live_far#1.treat, noabsorb 

use "data/extendedtable5/table5_left_c.dta",replace
eststo row_6_7: reghdfe performance engineer treat 1.engineer#1.treat, noabsorb 

use "data/extendedtable5/table5_left_d.dta",replace
eststo row_8_9: reghdfe performance female treat 1.female#1.treat, noabsorb 

use "data/extendedtable5/table5_left_e.dta",replace
eststo row_10_11: reghdfe performance manager treat 1.manager#1.treat, noabsorb 

use "data/extendedtable5/table5_left_f.dta",replace
eststo row_12_13: reghdfe performance tenure_above_median treat 1.tenure_above_median#1.treat, noabsorb 

use "data/extendedtable5/table5_left_g.dta",replace
eststo row_14_15: reghdfe performance treat_manager treat 1.treat_manager#1.treat, noabsorb 

use "data/extendedtable5/table5_left_h.dta",replace
eststo row_16_17: reghdfe performance volunteer treat 1.volunteer#1.treat, noabsorb 


esttab row_* using "tables/extendedtable5_left.tex", se nolabel nogaps replace b(%9.3f) se(%9.3f) drop(_cons) varlabels(treat "Hybrid WFH" treat_manager "Hybrid WFH manager" 1.treat_manager#1.treat "Hybrid WFH*Hybrid WFH manager" manager "Manager" 1.manager#1.treat "Hybrid WFH*Manager" tenure_above_median "Long tenure" 1.tenure_above_median#1.treat "Hybrid WFH*Long tenure" live_far "Long commute" 1.live_far#1.treat "Hybrid WFH*Long commute" female "Female" 1.female#1.treat "Hybrid WFH*Female" children "Children" 1.children#1.treat "Hybrid WFH*Children" volunteer "Volunteer" 1.volunteer#1.treat "Hybrid WFH*Volunteer" engineer "Engineer" 1.engineer#1.treat "Hybrid WFH*Engineer") nostar cells("b(fmt(3))" p(par(`"\{"' `"\}"') fmt(3))) mlabels(,none) collabels(,none)






* Promotion regressions

eststo clear
use "data/extendedtable5/table5_right_a.dta",replace

eststo row_1: reghdfe promotion treat, noabsorb 

eststo row_2_3: reghdfe promotion children treat 1.children#1.treat, noabsorb 

use "data/extendedtable5/table5_right_b.dta",replace
eststo row_4_5: reghdfe promotion live_far treat 1.live_far#1.treat, noabsorb 

use "data/extendedtable5/table5_right_c.dta",replace
eststo row_6_7: reghdfe promotion engineer treat 1.engineer#1.treat, noabsorb 

use "data/extendedtable5/table5_right_d.dta",replace
eststo row_8_9: reghdfe promotion female treat 1.female#1.treat, noabsorb 

use "data/extendedtable5/table5_right_e.dta",replace
eststo row_10_11: reghdfe promotion manager treat 1.manager#1.treat, noabsorb 

use "data/extendedtable5/table5_right_f.dta",replace
eststo row_12_13: reghdfe promotion tenure_above_median treat 1.tenure_above_median#1.treat, noabsorb 

use "data/extendedtable5/table5_right_g.dta",replace
eststo row_14_15: reghdfe promotion treat_manager treat 1.treat_manager#1.treat, noabsorb 

use "data/extendedtable5/table5_right_h.dta",replace
eststo row_16_17: reghdfe promotion volunteer treat 1.volunteer#1.treat, noabsorb 

esttab row_* using "tables/extendedtable5_right.tex", se nolabel nogaps replace b(%9.3f) se(%9.3f) drop(_cons) varlabels(treat "Hybrid WFH" treat_manager "Hybrid WFH manager" 1.treat_manager#1.treat "Hybrid WFH*Hybrid WFH manager" manager "Manager" 1.manager#1.treat "Hybrid WFH*Manager" tenure_above_median "Long tenure" 1.tenure_above_median#1.treat "Hybrid WFH*Long tenure" live_far "Long commute" 1.live_far#1.treat "Hybrid WFH*Long commute" female "Female" 1.female#1.treat "Hybrid WFH*Female" children "Children" 1.children#1.treat "Hybrid WFH*Children" volunteer "Volunteer" 1.volunteer#1.treat "Hybrid WFH*Volunteer" engineer "Engineer" 1.engineer#1.treat "Hybrid WFH*Engineer") nostar cells("b(fmt(3))" p(par(`"\{"' `"\}"') fmt(3))) mlabels(,none) collabels(,none)





