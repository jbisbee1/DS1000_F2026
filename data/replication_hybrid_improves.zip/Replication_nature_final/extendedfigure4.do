* ------------------------------------------------------------------------------
/* 	
*	Filename: 	extendedfigure4.do
			
*	Purpose:	This do file produces the revenue plot in "Hybrid Working from Home 
Improves Retention Without Damaging Performance"

*	Created by: Mert Akan
*	Created on: April 5, 2023
* 	Modified on: --
*/
* ------------------------------------------------------------------------------



set scheme stcolor
clear

import excel "data/extendedfigure4.xlsx", clear firstrow

drop Change Growth

gen year = year(FiscalYearEnd)
drop FiscalYearEnd
gen units = substr(Revenue, -1, .)

gen revenue = substr(Revenue, 1, length(Revenue) - 1)

drop Revenue

destring revenue, replace

replace revenue = revenue*10^9 if units == "B"

replace revenue = revenue*10^6 if units == "M"

replace revenue = revenue*10^3 if units == "K"

gen revenue_billion = revenue / 10^9

tsset year, yearly

twoway bar revenue_billion year,  barw(0.85) xscale(range(2000 2023)) xlab(2000(1)2023, nogrid angle(45)) ylab(0(1)6) fcolor(ebblue) lcolor(ebblue) ytitle("Revenue in billion USD") xtitle("Fiscal Year End")
graph export "figures/extendedfigure4.png", replace
