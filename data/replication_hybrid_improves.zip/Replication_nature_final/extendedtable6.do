
* ------------------------------------------------------------------------------
/* 	
*	Filename: 	extendedtable6.do
			
*	Purpose:	This do file produces the performance sub categories paper in "Hybrid Working from Home 
Improves Retention Without Damaging Performance"

*	Created by: Robin
*	Created on: --
* 	Modified by: Mert
* 	Modified on: March 20, 2024
*/
* ------------------------------------------------------------------------------


clear
use  "data/extendedtable6/Tasks2021H2.dta",replace

local l=0

foreach x of varlist Communication Development Efficiency Execution Innovation Leadership Learning Project Risk {
    ttest `x', by(treat)
    * Store results of ttest in a column matrix
    local totalObs = r(N_1) + r(N_2)
    matrix results`l' = (r(mu_2) \ r(mu_1) \ r(p) \ `totalObs')
	local l = `l' + 1

}

matrix A = results0, results1, results2, results3, results4, results5, results6, results7, results8

matrix colnames A = Communication Development Efficiency Execution Innovation Leadership Learning Project Risk
matrix rownames A = "Hybrid WFH (Treatment) Mean" "In-person (Control) Mean" "P-value of difference" N
esttab mat(A, fmt(a2 a2 a2 a2 a2 a2 a2 a2)) using "tables/extendedtable6_2021H2.tex", mlab(none) substitute(_ " ") replace f stats(\mline)

****************************
use  "data/extendedtable6/Tasks2022H1.dta",replace
local l=0

foreach x of varlist Communication Development Efficiency Execution Innovation Leadership Learning Project Risk {
    ttest `x', by(treat)
    * Store results of ttest in a column matrix
    local totalObs = r(N_1) + r(N_2)
    matrix results`l' = (r(mu_2) \ r(mu_1) \ r(p) \ `totalObs')
	local l = `l' + 1

}

matrix A = results0, results1, results2, results3, results4, results5, results6, results7, results8

matrix colnames A = Communication Development Efficiency Execution Innovation Leadership Learning Project Risk
matrix rownames A = "Hybrid WFH (Treatment) Mean" "In-person (Control) Mean" "P-value of difference" N
esttab mat(A, fmt(a2 a2 a2 a2 a2 a2 a2 a2)) using "tables/extendedtable6_2022H1.tex", mlab(none) substitute(_ " ") replace f stats(\mline)

**********************************
use  "data/extendedtable6/Tasks2022H2.dta",replace
local l=0

foreach x of varlist Communication Development Efficiency Execution Innovation Leadership Learning Project Risk {
    ttest `x', by(treat)
    * Store results of ttest in a column matrix
    local totalObs = r(N_1) + r(N_2)
    matrix results`l' = (r(mu_2) \ r(mu_1) \ r(p) \ `totalObs')
	local l = `l' + 1

}

matrix A = results0, results1, results2, results3, results4, results5, results6, results7, results8

matrix colnames A = Communication Development Efficiency Execution Innovation Leadership Learning Project Risk
matrix rownames A = "Hybrid WFH (Treatment) Mean" "In-person (Control) Mean" "P-value of difference" N
esttab mat(A, fmt(a2 a2 a2 a2 a2 a2 a2 a2)) using "tables/extendedtable6_2022H2.tex", mlab(none) substitute(_ " ") replace f stats(\mline)


***************************************
use  "data/extendedtable6/Tasks2023H1.dta",replace
local l=0

foreach x of varlist Communication Development Efficiency Execution Innovation Leadership Learning Project Risk {
    ttest `x', by(treat)
    * Store results of ttest in a column matrix
    local totalObs = r(N_1) + r(N_2)
    matrix results`l' = (r(mu_2) \ r(mu_1) \ r(p) \ `totalObs')
	local l = `l' + 1

}

matrix A = results0, results1, results2, results3, results4, results5, results6, results7, results8

matrix colnames A = Communication Development Efficiency Execution Innovation Leadership Learning Project Risk
matrix rownames A = "Hybrid WFH (Treatment) Mean" "In-person (Control) Mean" "P-value of difference" N
esttab mat(A, fmt(a2 a2 a2 a2 a2 a2 a2 a2)) using "tables/extendedtable6_2023H1.tex", mlab(none) substitute(_ " ") replace f stats(\mline)

