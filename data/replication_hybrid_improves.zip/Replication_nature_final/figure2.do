* ------------------------------------------------------------------------------
/* 	
*	Filename: 	figure2.do
			
*	Purpose:	This do file produces the attrition figures in "Hybrid Working from Home 
Improves Retention Without Damaging Performance"

*	Created by: Mert Akan
*	Created on: Aug 22, 2023
* 	Modified on: April 23, 2024
*/
* ------------------------------------------------------------------------------
clear
set more off
set scheme s2color


use "data/figure2.dta", clear

* ------------------------------------------------------------------------------
* Figure 2: Attrition for all employees
* ------------------------------------------------------------------------------
* Label treatment and control descriptively for the plot
la define treat_plot 0 "In-person (Control)" 1 "Hybrid WFH (Treatment)"
la values treat treat_plot

graph bar attrite_perc, over(treat) graphregion(color(white)) blabel(bar, format(%6.1f) size(large)) asyvars ytitle("Attrition (%)", size(vlarge)) ylab(0(2)10 ,labsize(large)) yscale(range(0,10)) bar(1, fcolor(navy)) bar(2, fcolor("orange_red")) title("All Employees", size(*1.3) color(black)) legend(symxsize(*0.5) ring(0) position(10) row(2) size(large) region(lstyle(none)) region(style(none)))
graph export "figures/figure2_1.pdf", replace
* Testing whether attrition rates differs by treatment status for all employees
ttest attrite_perc, by(treat)


* ------------------------------------------------------------------------------
* Figure 2: Attrition by role (manager and non-manager)
* ------------------------------------------------------------------------------
graph bar attrite_perc, over(treat) by(role, bgcolor(white) iscale(*1.6) note("") graphregion(color(white)) legend(off) ) blabel(bar, format(%6.1f) size(medium)) asyvars ytitle("Attrition (%)", size(vlarge)) ylab(0(2)10) yscale(range(0,10)) bar(1, fcolor(navy)) bar(2, fcolor(orange_red)) 
gr_edit .plotregion1.subtitle[1].style.editstyle drawbox(no) editcopy
graph export "figures/figure2_2.pdf", replace
* Testing whether attrition rates differs by treatment status for non-managers 
ttest attrite_perc if role == 0, by(treat)

* Testing whether attrition rates differs by treatment status for managers
ttest attrite_perc if role == 1, by(treat)

* ------------------------------------------------------------------------------
* Figure 2: Attrition by gender
* ------------------------------------------------------------------------------
graph bar attrite_perc, over(treat) by(male, iscale(*1.6) note("") graphregion(color(white)) legend(off) ) blabel(bar, format(%6.1f) size(medium)) asyvars ytitle("Attrition (%)", size(vlarge)) ylab(0(2)10) yscale(range(0,10)) bar(1, fcolor(navy)) bar(2, fcolor(orange_red))
gr_edit .plotregion1.subtitle[1].style.editstyle drawbox(no) editcopy
graph export "figures/figure2_3.pdf", replace

* Testing whether attrition rates differs by treatment status for males
ttest attrite_perc if male == 1, by(treat)
* Testing whether attrition rates differs by treatment status for females
ttest attrite_perc if male == 0, by(treat)

* ------------------------------------------------------------------------------
* Figure 2: Attrition by commute distance indicator
* ------------------------------------------------------------------------------
graph bar attrite_perc, over(treat) by(live_far, iscale(*1.6) note("") graphregion(color(white)) legend(off) ) blabel(bar, format(%6.1f) size(medium)) asyvars ytitle("Attrition (%)", size(vlarge)) ylab(0(2)10) yscale(range(0,10)) bar(1, fcolor(navy)) bar(2, fcolor(orange_red))
gr_edit .plotregion1.subtitle[1].style.editstyle drawbox(no) editcopy
graph export "figures/figure2_4.pdf", replace
* Testing whether attrition rates differs by treatment status for short commuters, defined to be <=90mins twoway (less than or equal to the median)
ttest attrite_perc if live_far == 0, by(treat)

* Testing whether attrition rates differs by treatment status for long commuters, defined to be >90mins twoway (above median)
ttest attrite_perc if live_far == 1, by(treat)





