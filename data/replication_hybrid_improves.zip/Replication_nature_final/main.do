* ------------------------------------------------------------------------------
/* 	
*	Filename: 	main.do
			
*	Purpose:	This do file runs all of the scripts for producing the tables
and figures in "Hybrid Working from Home 
Improves Retention Without Damaging Performance".

*	Created by: Mert Akan
*	Created on: Aug 22, 2023
* 	Modified on: April 23, 2024
*/
* ------------------------------------------------------------------------------
clear
cap set scheme stcolor	

* main figures
do "figure2.do"
do "figure3.do"
do "figure4.do"
do "figure5.do"

* extended figures and tables
do "extendedfigure1.do"
do "extendedfigure3.do"
do "extendedfigure4.do"
do "extendedtable1_extendedtable3_extendedtable7.do"
do "extendedtable2.do"
do "extendedtable4.do"
do "extendedtable5.do"
do "extendedtable6.do"
