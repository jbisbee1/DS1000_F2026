* ------------------------------------------------------------------------------
/* 	
*	Filename: 	extendedtable4.do
			
*	Purpose:	This do file produces the null results table in "Hybrid Working from Home 
Improves Retention Without Damaging Performance"

*	Created by:
*	Created on: Aug 24, 2023
* 	Modified on: March 20, 2024
*/
* ------------------------------------------------------------------------------


clear
set more off
set scheme s2color


* Storing performance t-tests and summary statistics in a matrix

* 2021H2 Performance
use "data/figure3/figure3_2021H2.dta", clear
ttest perf_2021h2, by(treat)
matrix A = r(N_1), r(mu_1), r(N_2), r(mu_2), `=r(mu_2)- r(mu_1)', r(se), r(p)

* 2022H1 Performance
use "data/figure3/figure3_2022H1.dta", clear
ttest perf_2022h1, by(treat)
matrix A=(A \ r(N_1), r(mu_1), r(N_2), r(mu_2), `=r(mu_2)- r(mu_1)', r(se), r(p))

* 2022H2 Performance
use "data/figure3/figure3_2022H2.dta", clear
ttest perf_2022h2, by(treat)
matrix A=(A \ r(N_1), r(mu_1), r(N_2), r(mu_2), `=r(mu_2)- r(mu_1)', r(se), r(p))

* 2023H1 Performance
use "data/figure3/figure3_2023H1.dta", clear
ttest perf_2023h1, by(treat)
matrix A=(A \ r(N_1), r(mu_1), r(N_2), r(mu_2), `=r(mu_2)- r(mu_1)', r(se), r(p))



* Storing performance t-tests and summary statistics in a matrix
use "data/figure4.dta", clear

* 2021H2 Promotion
ttest promo_2021h2, by(treat)
matrix A=(A \ r(N_1), r(mu_1), r(N_2), r(mu_2), `=r(mu_2)- r(mu_1)', r(se), r(p))

* 2022H1 Promotion
ttest promo_2022h1, by(treat)
matrix A=(A \ r(N_1), r(mu_1), r(N_2), r(mu_2), `=r(mu_2)- r(mu_1)', r(se), r(p))

* 2022H2 Promotion
ttest promo_2022h2, by(treat)
matrix A=(A \ r(N_1), r(mu_1), r(N_2), r(mu_2), `=r(mu_2)- r(mu_1)', r(se), r(p))

* 2023H1 Promotion
ttest promo_2023h1, by(treat)
matrix A=(A \ r(N_1), r(mu_1), r(N_2), r(mu_2), `=r(mu_2)- r(mu_1)', r(se), r(p))


* Storing lines of code t-tests and summary statistics in a matrix
use "data/extendedfigure1.dta", clear
ttest codelines, by(treat)
matrix A=(A \ r(N_1), r(mu_1), r(N_2), r(mu_2), `=r(mu_2)- r(mu_1)', r(se), r(p))

// mat colnames A = Control_Obs Control_Mean Treatment_Obs Treatment_Mean Diff. SE p-value
mat colnames A = "In-person (Control) Obs" "In-person Mean" "Hybrid WFH (Treatment) Obs" "Hybrid WFH Mean" "Diff." "SE" "p-value"

matrix rownames A ="Performance 2021 Jul-Dec" "Performance 2022 Jan-Jun" "Performance 2022 Jul-Dec" "Performance 2023 Jan-Jun" "Promotion 2021 Jul-Dec" "Promotion 2022 Jan-Jun" "Promotion 2022 Jul-Dec" "Promotion 2023 Jan-Jun"  "Lines of code"


esttab mat(A, fmt(0 2 0 2 2 2 2)) using "tables/extendedtable4.tex", mlab(none) substitute(_ " ") replace f stats(\mline)


