* ------------------------------------------------------------------------------
/* 	
*	Filename: 	extendedfigure3.do
			
*	Purpose:	This do file produces the takeup rate figure in "Hybrid Working from Home 
Improves Retention Without Damaging Performance"
*	Created by: Mert Akan
*	Created on: Aug 22, 2023
* 	Modified on: -
*/
* ------------------------------------------------------------------------------


clear
set more off
set scheme s2color

use "data/extendedfigure3.dta", clear
* ------------------------------------------------------------------------------
* Extended Figure 3: Take-up rate
* ------------------------------------------------------------------------------

local A=date("13sep2021","DMY")
local B=date("09aug2021","DMY")
local C=date("21jan2022","DMY")
graph twoway (line takeuprate date if volunteer == 0 & treat==0, sort lcolor(red) lwidth(0.6) ) (line takeuprate date if volunteer == 1 & treat==0,sort lcolor(blue) lwidth(0.6))(line takeuprate date if volunteer == 0 & treat==1,sort lcolor(green) lpattern(solid) lwidth(0.6))(line takeuprate date if volunteer == 1 & treat==1,sort lcolor(black) lwidth(0.6)), graphregion(color(white)) xlabel(22410 (30)22675,valuelabel angle(45))  xtitle("") title("") legend(size(small) ring(0) col(1) pos(10) order(3 4 1 2) region(style(none)) symxsize(*0.2) label(1 "Volunteer In-person (Control)") label(2 "Non-volunteer In-person (Control)") label(3 "Volunteer Hybrid WFH (Treatment)" ) label(4 "Non-volunteer Hybrid WFH (Treatment)")) xline(`A', lcolor(black%40) lstyle(refline)) xline(`B', lcolor(black%40) lstyle(refline)) ytitle("Take-up Rate") xline(`C', lcolor(red) lstyle(refline) lpattern(dash))
graph export "figures/extended_figure3.png", replace
