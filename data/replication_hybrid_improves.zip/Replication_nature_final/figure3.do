* ------------------------------------------------------------------------------
/* 	
*	Filename: 	figure3.do
			
*	Purpose:	This do file produces the performance figures in "Hybrid Working from Home 
Improves Retention Without Damaging Performance"

*	Created by: Mert Akan
*	Created on: Aug 22, 2023
* 	Modified on: April 23, 2024
*/
* ------------------------------------------------------------------------------
clear
set more off
set scheme s2color

* ------------------------------------------------------------------------------
* Figure 3: 2021 H2 Performance Plot
* ------------------------------------------------------------------------------
use "data/figure3/figure3_2021H2.dta", clear

* Testing whether 2021H2 performance reviews differs by treatment status 
ttest perf_2021h2, by(treat)

* Calculating the number of observations by treatment status and performance grade
bys treat perf_2021h2: gen num = _N

* Calculating the number of observations by treatment status
bys treat: gen denom = _N

* Calculating the share of employees by treatment and performance grade
gen percent = 100*(num/denom)

* collapse the data for the plot
duplicates drop treat perf_2021h2, force

* Label treatment and control descriptively for the plot
la define treat_plot 0 "In-person (Control)" 1 "Hybrid WFH (Treatment)"
la values treat treat_plot		
		
graph bar (asis) percent, graphregion(color(white)) over(treat, gap(0)) over(perf_2021h2, label(labsize(*1.5))) asyvars bar(1, fcolor(navy)) bar(2, fcolor(orange_red)) blabel(bar,format(%6.1f) size(4)) ytitle("Percent", size(vlarge)) title("2021 Jul-Dec Performance Review", margin(b=-2) size(vlarge) color(black)) legend(ring(0) bplacement(nwest) row(2) order(1 "In-person (Control)" 2 "Hybrid WFH (Treatment)") size(large) region(style(none)) symxsize(*0.5)) ylabel(0(10)70, labsize(large)) yscale(range(0 70))
graph export "figures/figure3_1.pdf", replace

* ------------------------------------------------------------------------------
* Figure 3: 2022 H1 Performance Plot
* ------------------------------------------------------------------------------
use "data/figure3/figure3_2022H1.dta", clear

* Testing whether 2022H1 performance reviews differs by treatment status 
ttest perf_2022h1, by(treat)

* Calculating the number of observations by treatment status and performance grade
bys treat perf_2022h1: gen num = _N

* Calculating the number of observations by treatment status
bys treat: gen denom = _N

* Calculating the share of employees by treatment and performance grade
gen percent = 100*(num/denom)

* collapse the data for the plot
duplicates drop treat perf_2022h1, force
	
graph bar (asis) percent, graphregion(color(white)) over(treat, gap(0)) over(perf_2022h1, label(labsize(*1.5))) asyvars bar(1, fcolor(navy)) bar(2, fcolor(orange_red)) blabel(bar,format(%6.1f) size(4)) ytitle("Percent", size(vlarge)) title("2022 Jan-Jun Performance Review", margin(b=-2) size(vlarge) color(black)) ylabel(0(10)70, labsize(large)) legend(off) yscale(range(0 70))
graph export "figures/figure3_2.pdf", replace

* ------------------------------------------------------------------------------
* Figure 3: 2022 H2 Performance Plot
* ------------------------------------------------------------------------------
use "data/figure3/figure3_2022H2.dta", clear

* Testing whether 2022H2 performance reviews differs by treatment status 
ttest perf_2022h2, by(treat)

* Calculating the number of observations by treatment status and performance grade
bys treat perf_2022h2: gen num = _N

* Calculating the number of observations by treatment status
bys treat: gen denom = _N

* Calculating the share of employees by treatment and performance grade
gen percent = 100*(num/denom)

* collapse the data for the plot
duplicates drop treat perf_2022h2, force

graph bar (asis) percent, graphregion(color(white)) over(treat, gap(0)) over(perf_2022h2, label(labsize(*1.5))) asyvars bar(1, fcolor(navy)) bar(2, fcolor(orange_red)) blabel(bar,format(%6.1f) size(4)) ytitle("Percent", size(vlarge)) title("2022 Jul-Dec Performance Review", margin(b=-2) size(vlarge) color(black)) ylabel(0(10)70, labsize(large)) legend(off) yscale(range(0 70))
graph export "figures/figure3_3.pdf", replace
* ------------------------------------------------------------------------------
* Figure 3: 2023 H1 Performance Plot
* ------------------------------------------------------------------------------
use "data/figure3/figure3_2023H1.dta", clear

* Testing whether 2023H1 performance reviews differs by treatment status 
ttest perf_2023h1, by(treat)

* Calculating the number of observations by treatment status and performance grade
bys treat perf_2023h1: gen num = _N

* Calculating the number of observations by treatment status
bys treat: gen denom = _N

* Calculating the share of employees by treatment and performance grade
gen percent = 100*(num/denom)

* collapse the data for the plot
duplicates drop treat perf_2023h1, force

graph bar (asis) percent, graphregion(color(white)) over(treat, gap(0)) over(perf_2023h1, label(labsize(*1.5))) asyvars bar(1, fcolor(navy)) bar(2, fcolor(orange_red)) blabel(bar,format(%6.1f) size(4)) ytitle("Percent", size(vlarge)) title("2023 Jan-Jun Performance Review", margin(b=-2) size(vlarge) color(black)) ylabel(0(10)70, labsize(large)) legend(off) yscale(range(0 70))
graph export "figures/figure3_4.pdf", replace 
