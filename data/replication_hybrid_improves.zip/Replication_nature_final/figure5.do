* ------------------------------------------------------------------------------
/* 	
*	Filename: 	figure5.do
			
*	Purpose:	This do file produces the productivity views figures in "Hybrid Working from Home 
Improves Retention Without Damaging Performance"

*	Created by: Mert Akan
*	Created on: Aug 22, 2023
* 	Modified on: April 23, 2024
*/
* ------------------------------------------------------------------------------


clear
set more off
set scheme s2color

use "data/figure5.dta",clear

* create an endline indicator variable
gen wave_n = 1 if wave == "endline"
replace wave_n = 0 if wave == "baseline"

* Testing whether productivity expectations differs by wave (endline vs baseline)
ttest prod_percent, by(wave_n)

* Calculating the number of observations by wave and productivity expectations
bys wave_n productivity: gen num = _N

* Calculating the number of observations by wave 
bys wave_n: gen denom = _N

* Calculating the share of employees by wave and productivity expectations
gen percent = 100*(num/denom)

* collapsing the data for plotting purposes
preserve
duplicates drop wave_n productivity, force

* ------------------------------------------------------------------------------
* Figure 5: Productivity Expectation Change
* ------------------------------------------------------------------------------
graph bar percent,graphregion(color(white)) over(wave, gap(0)) over(productivity,label(labsize(medium))) asyvars blabel(bar,format(%6.1f) size(3.5)) bar(2, color(ltblue) lcolor(ltblue)) bar(1, color(forest_green) lcolor(forest_green)) title("Productivity Expectations Change", color(black)) ytitle("Percent", size(large)) legend(order(1 2) label(1 "Baseline") label(2 "Endline") ring(0) bplacement(neast) size(large) region(style(none)) symxsize(*0.5) row(2)) ytitle("Percent") horizontal scheme(s2color) ylab(, labsize(4))
graph export "figures/figure5_1.pdf", replace
restore

* Testing whether productivity expectations differs by managerial status in endline
ttest prod_percent if wave == "endline", by(role) 

* Testing whether productivity expectations differs by managerial status in baseline
ttest prod_percent if wave == "baseline", by(role)

* ------------------------------------------------------------------------------
* Figure 5: Productivity Expectation Change by Managerial Status and Wave
* ------------------------------------------------------------------------------
graph bar prod_percent,  over(wave) exclude0 by(role, iscale(*1.6)  note("") graphregion(color(white))) blabel(bar,format(%6.1f)) ylab(-5(1)5) ytitle("Views on working from home on productivity", size(large)) yscale(range(-5(1)5))
gr_edit .plotregion1.subtitle[1].style.editstyle drawbox(no) editcopy

gr_edit .plotregion1.plotregion1[1].bars[1].style.editstyle shadestyle(color(forest_green)) editcopy
gr_edit .plotregion1.plotregion1[1].bars[1].style.editstyle linestyle(color(forest_green)) editcopy
// bars[1] color

gr_edit .plotregion1.plotregion1[1].bars[2].EditCustomStyle , j(-1) style(shadestyle(color(ltblue)))
gr_edit .plotregion1.plotregion1[1].bars[2].EditCustomStyle , j(-1) style(linestyle(color(ltblue)))
// bars[2] color

gr_edit .plotregion1.plotregion1[2].bars[2].EditCustomStyle , j(-1) style(shadestyle(color(ltblue)))
gr_edit .plotregion1.plotregion1[2].bars[2].EditCustomStyle , j(-1) style(linestyle(color(ltblue)))
// bars[2] color
graph export "figures/figure5_2.pdf", replace

* ------------------------------------------------------------------------------
* Expectation change from baseline to endline quoted in line 208
* ------------------------------------------------------------------------------
/*
use "data/beliefupdate.dta",clear
ttest change, by(treat) 
reg change treat
*/
