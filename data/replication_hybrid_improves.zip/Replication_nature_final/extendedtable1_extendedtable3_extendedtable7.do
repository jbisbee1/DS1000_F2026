* ------------------------------------------------------------------------------
/* 	
*	Filename: extendedtable1_extendedtable3_extendedtable7.do
			
*	Purpose:	This do file produces the descriptive statistics table, the
balance table and the volunteer table in "Hybrid Working from Home 
Improves Retention Without Damaging Performance"

*	Created by: Mert
*	Created on: Aug 22, 2023
* 	Modified on: April 16, 2024
*/
* ------------------------------------------------------------------------------


clear
set more off
set scheme s2color

* installing packages needed if not downloaded
cap which outreg 
if _rc ssc install outreg 
cap which estout 
if _rc ssc install estout
cap which reghdfe
if _rc ssc install reghdfe
cap which ftools
if _rc ssc install ftools

* ------------------------------------------------------------------------------
* Extended Table 1: Descriptive Statistics 
* ------------------------------------------------------------------------------	
use "data/extendedtable137_a", clear
la var treat "Hybrid WFH (Treatment)"

est clear  // clear the stored estimates
estpost tabstat age children_ind commute_hour female managerial grad tenure_years treat, stat(n mean  sd min p10 median p90 max) col(stat)

esttab using "tables/extendedtable1_a.tex", replace ///
 cells("count mean(fmt(%6.2fc)) sd(fmt(%6.2fc)) min(fmt(a2)) p10(fmt(a2)) p50(fmt(a2)) p90(fmt(a2)) max(fmt(a2)) ") nonumber ///
  nomtitle nonote noobs label booktabs ///
  collabels("n" "mean" "sd" "min" "p10" "median" "p90" "max")	
    
  
* Analyzing performance separately 
use "data/extendedtable137_b", clear 	
esttab using "tables/extendedtable1_b.tex", replace ////
 cells("count mean(fmt(%6.2fc)) sd(fmt(%6.2fc)) min(fmt(a2)) p10(fmt(a2)) p50(fmt(a2)) p90(fmt(a2)) max(fmt(a2)) ") nonumber ///
  nomtitle nonote noobs label booktabs ///
  collabels("n" "mean" "sd" "min" "p10" "median" "p90" "max")	 
  
 
* ------------------------------------------------------------------------------
* Extended Table 7: Balance
* ------------------------------------------------------------------------------
use "data/extendedtable137_a", clear	

global DESCVARS age children_ind commute_hour female managerial grad tenure_years
mata: mata clear

local i = 1
foreach var in $DESCVARS {
    reg `var' treat
    outreg, keep(treat)  rtitle("`: var label `var''") stats(b) ///
	noautosumm store(row`i') 
    outreg, replay(diff) append(row`i') ctitles("",Difference ) ///
        store(diff) note("")
    local ++i
}
outreg, replay(diff)

local i = 1

foreach var in $DESCVARS {
    reg `var' treat
    outreg, keep(treat)  rtitle("`: var label `var''") stats(p) ///
        noautosumm store(row`i') 
    outreg, replay(pvals) append(row`i') ctitles("",P-values ) ///
        store(pvals) note("")
    local ++i
}
outreg, replay(pvals)	

local count: word count $DESCVARS
mat sumstat = J(`count',6,.)

local i = 1
foreach var in $DESCVARS {
    quietly: summarize `var' if treat==0
    mat sumstat[`i',1] = r(N)
    mat sumstat[`i',2] = r(mean)
    mat sumstat[`i',3] = r(sd)
    quietly: summarize `var' if treat==1
    mat sumstat[`i',4] = r(N)
    mat sumstat[`i',5] = r(mean)
    mat sumstat[`i',6] = r(sd)
    local i = `i' + 1
}
frmttable, statmat(sumstat) store(sumstat) sfmt(g,f,f,g,f,f)

outreg, ///
    replay(sumstat) merge(diff) tex nocenter note("") fragment plain replace ///
    ctitles("", Control, "", "", Treatment, "", "", "" \ "", n, mean, sd, n, mean, sd, Diff) ///
    multicol(1,2,3;1,5,3) 		
outreg using "tables/extendedtable7_a.tex", ///
    replay(sumstat) merge(pvals) tex nocenter note("") fragment plain replace ///
    ctitles("", Control, "", "", Treatment, "", "", "" \ "", n, mean, sd, n, mean, sd, Diff., p-value) ///
    multicol(1,2,3;1,5,3) 
	
	
	
* Analyzing performance separately for data privacy  

use "data/extendedtable137_b", clear
global DESCVARS prior_performance
mata: mata clear



local i = 1
foreach var in $DESCVARS {
    reg `var' treat, r
    outreg, keep(treat)  rtitle("`: var label `var''") stats(b) ///
	noautosumm store(row`i') 
    outreg, replay(diff) append(row`i') ctitles("",Difference ) ///
        store(diff) note("")
    local ++i
}
outreg, replay(diff)

local i = 1
foreach var in $DESCVARS {
    reg `var' treat, r
    outreg, keep(treat)  rtitle("`: var label `var''") stats(p) ///
        noautosumm store(row`i') 
    outreg, replay(pvals) append(row`i') ctitles("",P-values ) ///
        store(pvals) note("")
    local ++i
}
outreg, replay(pvals)	

local count: word count $DESCVARS
mat sumstat = J(`count',6,.)

local i = 1
foreach var in $DESCVARS {
    quietly: summarize `var' if treat==0
    mat sumstat[`i',1] = r(N)
    mat sumstat[`i',2] = r(mean)
    mat sumstat[`i',3] = r(sd)
    quietly: summarize `var' if treat==1
    mat sumstat[`i',4] = r(N)
    mat sumstat[`i',5] = r(mean)
    mat sumstat[`i',6] = r(sd)
    local i = `i' + 1
}
frmttable, statmat(sumstat) store(sumstat) sfmt(g,f,f,g,f,f)

outreg, ///
    replay(sumstat) merge(diff) tex nocenter note("") fragment plain replace ///
    ctitles("", Control, "", "", Treatment, "", "", "" \ "", n, mean, sd, n, mean, sd, Diff) ///
    multicol(1,2,3;1,5,3) 
	
	
outreg using "tables/extendedtable7_b.tex", ///
    replay(sumstat) merge(pvals) tex nocenter note("") fragment plain replace ///
    ctitles("", Control, "", "", Treatment, "", "", "" \ "", n, mean, sd, n, mean, sd, Diff., p-value) ///
    multicol(1,2,3;1,5,3) 	

* ------------------------------------------------------------------------------
* Extended Table 3: Volunteer
* ------------------------------------------------------------------------------	
use "data/extendedtable137_a", clear	
global DESCVARS age children_ind commute_hour female managerial grad tenure_years
	

* reversing the indicator for volunteer to have the difference computed as volunteer - nonvolunteer	
gen not_volunteer = 0 if volunteer == 1
replace not_volunteer = 1 if volunteer == 0	
	

est clear
estpost ttest $DESCVARS, by(not_volunteer)	
ereturn list	

esttab using "tables/extendedtable3_a.tex", replace ///
  cells("N_2(fmt(0)) mu_2(fmt(2)) N_1(fmt(0))  mu_1(fmt(2))  b(fmt(2)) p(fmt(2))") ///
  collabels("Non-volunteer Obs" "Non-volunteer Mean" "Volunteer Obs" "Volunteer Mean" "Diff." "p-value" ) ///
  star(* 0.10 ** 0.05 *** 0.01) ///
  label booktabs nonum gaps noobs compress		
 	
* Analyzing performance separately for data privacy  	
use "data/extendedtable137_b", clear	
global DESCVARS prior_performance

* reversing the indicator for volunteer to have the difference computed as volunteer - nonvolunteer	
gen not_volunteer = 0 if volunteer == 1
replace not_volunteer = 1 if volunteer == 0	

est clear
estpost ttest $DESCVARS, by(not_volunteer)	
ereturn list	

esttab using "tables/extendedtable3_b.tex", replace ///
  cells("N_2(fmt(0)) mu_2(fmt(2)) N_1(fmt(0))  mu_1(fmt(2))  b(fmt(2)) p(fmt(2))") ///
  collabels("Non-volunteer Obs" "Non-volunteer Mean" "Volunteer Obs" "Volunteer Mean" "Diff." "p-value" ) ///
  star(* 0.10 ** 0.05 *** 0.01) ///
  label booktabs nonum gaps noobs compress			
	




	