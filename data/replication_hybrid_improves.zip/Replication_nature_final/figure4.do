* ------------------------------------------------------------------------------
/* 	
*	Filename: 	figure4.do
			
*	Purpose:	This do file produces the promotion figures in "Hybrid Working from Home 
Improves Retention Without Damaging Performance"

*	Created by: Mert Akan
*	Created on: Aug 22, 2023
* 	Modified on: April 23, 2024
*/
* ------------------------------------------------------------------------------
clear
set more off
set scheme s2color

use "data/figure4.dta", clear

* ------------------------------------------------------------------------------
* Figure 4: 2021 H2 Promotion Plot
* ------------------------------------------------------------------------------
graph bar promo_2021h2, graphregion(color(white)) over(treat, gap(0) label(labsize(*1.5))) blabel(bar,format(%6.1f)) asyvars bar(1, fcolor(navy)) bar(2, fcolor(orange_red)) blabel(bar,format(%6.1f) size(5)) ytitle("Percent", size(vlarge)) title("2021 Jul-Dec Promotion", margin(b=-2) size(vlarge) color(black)) legend(ring(0) bplacement(nwest) row(2) order(1 "In-person (Control)" 2 "Hybrid WFH (Treatment)") size(large) region(style(none)) symxsize(*0.5)) ylabel(0(2)12, labsize(large)) yscale(range(0 12))
graph export "figures/figure4_1.pdf", replace
* Testing whether 2021H2 promotions differs by treatment status 
ttest promo_2021h2, by(treat)  

* ------------------------------------------------------------------------------
* Figure 4: 2022 H1 Promotion Plot
* ------------------------------------------------------------------------------
graph bar promo_2022h1, graphregion(color(white)) over(treat, gap(0) label(labsize(*1.5))) blabel(bar,format(%6.1f)) asyvars bar(1, fcolor(navy)) bar(2, fcolor(orange_red)) blabel(bar,format(%6.1f) size(5)) ytitle("Percent", size(vlarge)) title("2022 Jan-Jun Promotion", margin(b=-2) size(vlarge) color(black)) ylabel(0(2)12, labsize(large)) yscale(range(0 12)) legend(off)
graph export "figures/figure4_2.pdf", replace
* Testing whether 2022H1 promotions differs by treatment status 
ttest promo_2022h1, by(treat) 

* ------------------------------------------------------------------------------
* Figure 4: 2022 H2 Promotion Plot
* ------------------------------------------------------------------------------
graph bar promo_2022h2, graphregion(color(white)) over(treat, gap(0) label(labsize(*1.5))) blabel(bar,format(%6.1f)) asyvars bar(1, fcolor(navy)) bar(2, fcolor(orange_red)) blabel(bar,format(%6.1f) size(5)) ytitle("Percent", size(vlarge)) title("2022 Jul-Dec Promotion", margin(b=-2) size(vlarge) color(black)) ylabel(0(2)12, labsize(large)) yscale(range(0 12)) legend(off)
graph export "figures/figure4_3.pdf", replace
* Testing whether 2022H2 promotions differs by treatment status 
ttest promo_2022h2, by(treat) 

* ------------------------------------------------------------------------------
* Figure 4: 2023 H1 Promotion Plot
* ------------------------------------------------------------------------------
graph bar promo_2023h1, graphregion(color(white)) over(treat, gap(0) label(labsize(*1.5))) blabel(bar,format(%6.1f)) asyvars bar(1, fcolor(navy)) bar(2, fcolor(orange_red)) blabel(bar,format(%6.1f) size(5)) ytitle("Percent", size(vlarge)) title("2023 Jan-Jun Promotion", margin(b=-2) size(vlarge) color(black)) ylabel(0(2)12, labsize(large)) yscale(range(0 12)) legend(off)
graph export "figures/figure4_4.pdf", replace
* Testing whether 2023H1 promotions differs by treatment status 
ttest promo_2023h1, by(treat) 

