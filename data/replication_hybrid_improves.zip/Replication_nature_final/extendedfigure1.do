* ------------------------------------------------------------------------------
/* 	
*	Filename: 	extendedfigure1.do
			
*	Purpose:	This do file produces the lines of code histogram for treatment
and control in "Hybrid Working from Home 
Improves Retention Without Damaging Performance"

*	Created by: Mert Akan
*	Created on: Aug 22, 2023
* 	Modified on: March 20, 2024
*/
* ------------------------------------------------------------------------------


clear
set more off
set scheme s2color

use "data/extendedfigure1.dta"

* Testing whether lines of code differ by treatment status
ttest codelines, by(treat) 

* Testing whether log2(lines of code) differ by treatment status
ttest log2_codelines, by(treat) 

* Testing whether log2(lines of code+1) differ by treatment status
ttest log2_codelines_1, by(treat)

* ------------------------------------------------------------------------------
* Extended Figure 1: Histogram of Lines of code
* ------------------------------------------------------------------------------
twoway (histogram log2_codelines if treat == 1, color(teal) graphregion(color(white)) xlabel(0 "1" 1 "2" 2 "4" 3 "8" 4 "16" 5 "32" 6 "64" 7 "128" 8 "256" 9 "512" 10 "1024" 11 "2048") width(0.5)) (histogram log2_codelines if treat == 0, legend(ring(0) bplacement(nwest) size(medium) region(style(none)) symxsize(*0.5) row(2) order(2 "In-person (Control)" 1 "Hybrid WFH (Treatment)")) fcolor(none) lcolor(black) xlabel(0 "1" 1 "2" 2 "4" 3 "8" 4 "16" 5 "32" 6 "64" 7 "128" 8 "256" 9 "512" 10 "1024" 11 "2048" 12 "4096" 13 "8192" 14 "16384") width(0.5) scheme(s2color) xtitle("Lines of Code") xlabel(,angle(45))) 
graph export "figures/extendedfigure1.png", replace

