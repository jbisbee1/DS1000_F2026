# DS 1000 Evidence Debate 3 — Remote Work

## Claim
**“Working from home makes employees more productive.”**

This package follows the staged Evidence Debate architecture used elsewhere in DS 1000:
Stage 0 prior judgment → Evidence A → Evidence B → Evidence C → Evidence D → Evidence E → team argument → individual adjudication.

## Evidence sequence
- **A — 2015 CTrip randomized experiment:** home working increased measured performance by 13%.
- **B — What does productivity mean?** About 9 percentage points of that gain came from more minutes worked and about 4 from more calls per minute.
- **C — 2024 Trip.com randomized experiment:** 1,612 graduate employees were randomized to hybrid or office work. The study found no meaningful damage to performance; attrition fell from 7.2% to 4.8%.
- **D — Contrary evidence:** two studies that found productivity losses. Atkin, Schoar & Shinde (randomized, data-entry workers in India) found output about 18% lower at home. Gibbs, Mengel & Siemroth (before/after, 10,000+ IT employees during Covid-19) found hours up about 30% and productivity down 8-19%. The pair lets students compare a randomized estimate with one that has no control group and a pandemic confound.
- **E — External validity:** a four-study comparison of workers, treatments and designs; the broad claim requires a generalization beyond any one study.

## Sources
1. Bloom, Nicholas, James Liang, John Roberts, and Zhichun Jenny Ying. “Does Working from Home Work? Evidence from a Chinese Experiment.” *Quarterly Journal of Economics* 130(1), 2015, 165–218. DOI: 10.1093/qje/qju032.
2. Bloom, Nicholas, Ruobing Han, and James Liang. “Hybrid working from home improves retention without damaging performance.” *Nature* 630, 2024, 920–925. DOI: 10.1038/s41586-024-07500-2.
3. Atkin, David, Antoinette Schoar, and Sumit Shinde. "Working from Home, Worker Sorting and Development." NBER Working Paper 31515, 2023 (working paper).
4. Gibbs, Michael, Friederike Mengel, and Christoph Siemroth. "Work from Home and Productivity: Evidence from Personnel and Analytics Data on IT Professionals." *Journal of Political Economy Microeconomics* 1(1), 2023, 7-41.

## Supabase setup
The page writes to the existing `debate_responses` table. Insert the same Supabase project URL and publishable key used by the working DS 1000 debate pages into `index.html`:

```js
const SUPABASE_URL = "...";
const SUPABASE_KEY = "...";
```

The activity uses:
`debate_id = "evidence-debate-3-remote-work"`

No new table is required if the existing anonymous INSERT policy on `debate_responses` remains active.

## Student-code note
The page currently accepts a course student code and persists it in browser local storage. Before deployment, implement the course-level student-code linkage plan so the same assigned code is used across all five debates.

## Testing
To reset the reveal sequence during development, clear this local-storage key in the browser console:

```js
localStorage.removeItem("ds1000_evidence_debate3_remote_stage")
```

Reload the page afterward.

## Files
- `index.html` — student-facing staged debate
- `assets/evidence_A_ctrip_2015.png`
- `assets/evidence_B_mechanism.png`
- `assets/evidence_C_attrition.png`
- `assets/evidence_D_contrary.png`
- `assets/evidence_E_comparison.png`
- `remote_prep.R` — regenerates the D and E figures (run from this folder)

All evidence figures are clickable and open in a full-screen modal.
